const serverless = require('serverless-http');
const express = require('express');
const massive = require('massive');
const app = express()

massive(config.connection).then( db => {
  app.set('db', db)
  console.log('db')
}).catch( err => {
  console.log(err)    
})

app.get('/', function (req, res) {
  res.send('Hello World!')
})

module.exports.handler = serverless(app);