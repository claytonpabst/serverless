module.exports = {
  port:8085,
  secret:"kdjfkKLJKGK*$#&7848478KDN?!*#NJKDKSjdvo84783",
  connection: {
    host: 'ec2-54-235-160-57.compute-1.amazonaws.com',
    port: 5432,
    database: 'd6m1vtij7efvvj',
    user: 'iypbvvalsxmicx',
    password: '45ab3677dc8fddcd4b40ed53eb54ba1bcef0a42aae04d05b489321eb15f342b0',
    ssl: true,
  },
}